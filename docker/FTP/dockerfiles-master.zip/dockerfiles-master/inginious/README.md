# INGInious containers

Some self-made containers for [INGInious](https://github.com/UCL-INGI/INGInious), an intelligent grader that allows secured and automated testing of code made by students.

All containers are under GPL license.
