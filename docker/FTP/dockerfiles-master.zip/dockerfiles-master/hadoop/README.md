# Simplified version of https://hub.docker.com/r/sequenceiq/hadoop-docker
